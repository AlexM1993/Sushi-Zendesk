
const client = ZAFClient.init();
client.invoke("resize", { width: "100%", height: "265px" });


  const button = document.getElementById("bigButton");
  const nickButton = document.getElementById("nickNameButton")

  ///////////deactivation button code below///////////

  button.addEventListener("click", async () => {

    if (document.getElementById("userEmail").value != "") {

    const error = () => {
        document.getElementById("userEmail").value = "";
        document.getElementById("userEmail").placeholder ="Couldn't find account :("
      };
  

    const optionsGet = {
     url:`https://api.faceit.com/users/v1/users?email=${document.getElementById("userEmail").value.toLowerCase()}`,
     type: "GET",
     headers:{
      "Authorization": "Bearer 1ab626fd-d528-4b83-a666-43bebf9163e5",
     },
     dataType: "json",
    };
  
    
    const response = await client.request(optionsGet);

    try {

    const updated = () => {
      document.getElementById("userEmail").value = "";
      document.getElementById("userEmail").placeholder =`Deactivated ${response.payload[0].nickname}`};
      client.invoke('resize', { width: '100%', height: '350px' });
      const newDiv = document.createElement("div");
      const newContent = document.createTextNode(`https://backoffice.faceit.com/#/users/${response.payload[0].id}`);
      newDiv.appendChild(newContent);
      const currentDiv = document.getElementById("div1");
      document.body.insertBefore(newDiv, currentDiv);

    
    const id = response.payload[0].id;
    

     const optionsPut = {
       url: `https://api.faceit.com/users/v1/users/${id}`,
       type: "PUT",
       headers:{
         "Accept": "*/*",
         "Accept-Encoding": "gzip, deflate, br",
         "Connection": "keep-alive",
         "accept": "application/json",
         "accept-language": "en-US,en;q=0.9",
         "Authorization": "Bearer 1ab626fd-d528-4b83-a666-43bebf9163e5",
         "authority": "api.faceit.com",
         "content-type": "application/json;charset=UTF-8",
        //  "faceit-referer": "faceit-backoffice",
        //  "origin": "https://backoffice.faceit.com",
        //  "referer": "https://backoffice.faceit.com/",
       },
       contentType: "application/json",
       dataType: "text",
       data: JSON.stringify( { 
        "registration_status": "deactivated",})
            
     };


    const put = await client.request(optionsPut); 
    updated(); 
  
  } catch (err) {
    error()
  }
    } else {
      document.getElementById("userEmail").placeholder = "Field cannot be blank"}
  }),

////////////////////////////Release about button below//////////////////////////////////

  nickButton.addEventListener("click", async () => {

    if (document.getElementById("userNickname").value != "") {

    const error = () => {
        document.getElementById("userNickname").value = "";
        document.getElementById("userNickname").placeholder ="Couldn't find account :("
      };
  

      const optionsGet = {
        url:`https://api.faceit.com/users/v1/nicknames/${document.getElementById("userNickname").value}`,
        type: "GET",
        headers:{
         "Authorization": "Bearer 1ab626fd-d528-4b83-a666-43bebf9163e5",
        },
        dataType: "json",};
  
    
    try {const response = await client.request(optionsGet);
    
    
    try {

    const updated = () => {
      document.getElementById("userNickname").value = "";
      document.getElementById("userNickname").placeholder = "Success"};
      

    
    const id = response.payload.id;
    

     const optionsPut = {
       url: `https://api.faceit.com/users/v1/users/${id}`,
       type: "PUT",
       headers:{
         "Accept": "*/*",
         "Accept-Encoding": "gzip, deflate, br",
         "Connection": "keep-alive",
         "accept": "application/json",
         "accept-language": "en-US,en;q=0.9",
         "Authorization": "Bearer 1ab626fd-d528-4b83-a666-43bebf9163e5",
         "authority": "api.faceit.com",
         "content-type": "application/json;charset=UTF-8",
        //  "faceit-referer": "faceit-backoffice",
        //  "origin": "https://backoffice.faceit.com",
        //  "referer": "https://backoffice.faceit.com/",
       },
       contentType: "application/json",
       dataType: "text",
       data: JSON.stringify( { 
        "about":"",})
            
     };


    const put = await client.request(optionsPut); 
    updated(); 
  
  } catch (err) {
    error()
  } }
  catch {error()}
    } else {
      document.getElementById("userNickname").placeholder = "Field cannot be blank"} 
  })




  

  // "faceit-referer": "faceit-backoffice",
  //        "origin": "https://backoffice.faceit.com",
  //        "referer": "https://backoffice.faceit.com/",
         
//   curl https://faceitsupport.zendesk.com/api/services/zis/registry/faceot_integration_development_acme1234 \
//   -d '{"description": "faceit integration oauth test"}' \
//   -H "Content-type: application/json" \
//   -v -u a.mattingley@efg.gg/token:JkDt58J0auLUxnaikFNEHfGdhX4sqoslo2nzyz5F -X POST

//   curl https://faceitsupport.zendesk.com/api/v2/oauth/tokens.json \
//  -H "Content-Type: application/json" \
//  -d '{"token": {"client_id": 7712625589276, "scopes": ["read", "write"]}}' \
//  -X POST -v -u a.mattingley@efg.gg/token:JkDt58J0auLUxnaikFNEHfGdhX4sqoslo2nzyz5F



  //  curl -X POST https://faceitsupport.zendesk.com/api/services/zis/connections/oauth/clients/faceot_integration_development_acme1234 \
  //  -H "Authorization: Bearer 2f257161b1955aa825e272188147c3c0771125d3720f7b1e823a5aef392bc8b2" \
  //  -H "Content-type: application/json" \
  //  -d '{
  //    "name": "Client_FIcMTWWQnV",
  //    "client_id": "8681fd35-c05f-4cdf-91db-f86d5f871732",
  //    "client_secret": "ys8axUhnACLLjszA3xn7wLv8rBCNicN8xUI8Pwmv",
  //    "grant_type": "authorization_code",
  //    "default_scopes": "chat:write",
  //    "auth_url": "https://api.faceit.com/auth/v1/api/authorize",
  //    "token_url": "https://api.faceit.com/auth/v1/oauth/token"
  //  }'

  //  curl -X POST https://faceitsupport.zendesk.com/api/services/zis/connections/oauth/start/faceot_integration_development_acme1234 \
  //  -H "Authorization: Bearer 2f257161b1955aa825e272188147c3c0771125d3720f7b1e823a5aef392bc8b2" \
  //  -H 'content-type: application/json' \
  //  -d '{
  //    "name": "faceit",
  //    "oauth_client_name": "Client_FIcMTWWQnV",
  //    "grant_type": "authorization_code",
  //    "origin_oauth_redirect_url": "https://zis.zendesk.com/api/services/zis/connections/oauth/callback",
  //    "permission_scopes": "chat:write",
  //    "allow_offline_access": true
  //  }'


  //  curl https://faceitsupport.zendesk.com/api/services/zis/connections/faceot_integration_development_acme1234?uuid=ac976b9c-eaa5-47db-af9a-52e1cf7c967c \
  //  -H "Authorization: Bearer 2f257161b1955aa825e272188147c3c0771125d3720f7b1e823a5aef392bc8b2"


  //TODO: add back in manifest.json when token is working
  // "parameters": [
  //   {
  //     "name": "token",
  //     "type": "oauth"
  //   }
  // ],
  // "oauth": {
  //   "client_id": "8681fd35-c05f-4cdf-91db-f86d5f871732",
  //   "client_secret": "ys8axUhnACLLjszA3xn7wLv8rBCNicN8xUI8Pwmv",
  //   "authorize_uri":"https://api.faceit.com/auth/v1/api/authorize", 
  //   "access_token_uri":"https://api.faceit.com/auth/v1/oauth/token",
  //   "scope": "read write"
  // }