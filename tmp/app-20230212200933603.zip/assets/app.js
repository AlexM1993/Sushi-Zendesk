
const client = ZAFClient.init();
client.invoke("resize", { width: "95%", height: "175px" });


  const button = document.getElementById("bigButton");

  ///////////button code below///////////

  button.addEventListener("click", async () => {

    if (document.getElementById("userEmail").value != "") {

    const error = () => {
        document.getElementById("userEmail").value = "";
        document.getElementById("userEmail").placeholder ="Couldn't find account :("
      };
  

    const optionsGet = {
     url:`https://api.faceit.com/users/v1/users?email=${document.getElementById("userEmail").value.toLowerCase()}`,
     type: "GET",
     headers:{
      "Authorization": "Bearer {{setting.token}}",
     },
     dataType: "json",
     secure: true,
    };
  
    
    const response = await client.request(optionsGet);

    try {

    const updated = () => {
      document.getElementById("userEmail").value = "";
      document.getElementById("userEmail").placeholder =`${response.payload[0].nickname} has been deactivated :)`};
      client.invoke('resize', { width: '95%', height: '300px' });
      const newDiv = document.createElement("div");
      const newContent = document.createTextNode(`https://backoffice.faceit.com/#/users/${response.payload[0].id}`);
      newDiv.appendChild(newContent);
      const currentDiv = document.getElementById("div1");
      document.body.insertBefore(newDiv, currentDiv);

    
    const id = response.payload[0].id;
    

     const optionsPut = {
       url: `https://api.faceit.com/users/v1/users/${id}`,
       type: "PUT",
       headers:{
         "Accept": "*/*",
         "Accept-Encoding": "gzip, deflate, br",
         "Connection": "keep-alive",
         "accept": "application/json",
         "accept-language": "en-US,en;q=0.9",
         "Authorization": "Bearer {{setting.token}}",
         "authority": "api.faceit.com",
         "content-type": "application/json;charset=UTF-8",
         "faceit-referer": "faceit-backoffice",
         "origin": "https://backoffice.faceit.com",
         "referer": "https://backoffice.faceit.com/",
     
       },
       contentType: "application/json",
       secure: true,
       dataType: "text",
       data: JSON.stringify( { "registration_status": "deactivated" })
              
     };


    const put = await client.request(optionsPut); 
    updated(); 
  
  } catch (err) {
    error()
  }
    } else {
      document.getElementById("userEmail").placeholder = "Field cannot be blank"}
  
  })
         
//   curl https://faceitsupport.zendesk.com/api/services/zis/registry/faceot_integration_development_acme1234 \
//   -d '{"description": "faceit integration oauth test"}' \
//   -H "Content-type: application/json" \
//   -v -u a.mattingley@efg.gg/token:JkDt58J0auLUxnaikFNEHfGdhX4sqoslo2nzyz5F -X POST

//   curl https://faceitsupport.zendesk.com/api/v2/oauth/tokens.json \
//  -H "Content-Type: application/json" \
//  -d '{"token": {"client_id": 7712625589276, "scopes": ["read", "write"]}}' \
//  -X POST -v -u a.mattingley@efg.gg/token:JkDt58J0auLUxnaikFNEHfGdhX4sqoslo2nzyz5F



  //  curl -X POST https://faceitsupport.zendesk.com/api/services/zis/connections/oauth/clients/faceot_integration_development_acme1234 \
  //  -H "Authorization: Bearer 2f257161b1955aa825e272188147c3c0771125d3720f7b1e823a5aef392bc8b2" \
  //  -H "Content-type: application/json" \
  //  -d '{
  //    "name": "Client_FIcMTWWQnV",
  //    "client_id": "8681fd35-c05f-4cdf-91db-f86d5f871732",
  //    "client_secret": "ys8axUhnACLLjszA3xn7wLv8rBCNicN8xUI8Pwmv",
  //    "grant_type": "authorization_code",
  //    "default_scopes": "chat:write",
  //    "auth_url": "https://api.faceit.com/auth/v1/api/authorize",
  //    "token_url": "https://api.faceit.com/auth/v1/oauth/token"
  //  }'

  //  curl -X POST https://faceitsupport.zendesk.com/api/services/zis/connections/oauth/start/faceot_integration_development_acme1234 \
  //  -H "Authorization: Bearer 2f257161b1955aa825e272188147c3c0771125d3720f7b1e823a5aef392bc8b2" \
  //  -H 'content-type: application/json' \
  //  -d '{
  //    "name": "faceit",
  //    "oauth_client_name": "Client_FIcMTWWQnV",
  //    "grant_type": "authorization_code",
  //    "origin_oauth_redirect_url": "https://zis.zendesk.com/api/services/zis/connections/oauth/callback",
  //    "permission_scopes": "chat:write",
  //    "allow_offline_access": true
  //  }'


  //  curl https://faceitsupport.zendesk.com/api/services/zis/connections/faceot_integration_development_acme1234?uuid=ac976b9c-eaa5-47db-af9a-52e1cf7c967c \
  //  -H "Authorization: Bearer 2f257161b1955aa825e272188147c3c0771125d3720f7b1e823a5aef392bc8b2"

