
const client = ZAFClient.init();
client.invoke("resize", { width: "95%", height: "175px" });


  const button = document.getElementById("bigButton");

  ///////////button code below///////////

  button.addEventListener("click", async () => {

    if (document.getElementById("userEmail").value != "") {

    const error = () => {
        document.getElementById("userEmail").value = "";
        document.getElementById("userEmail").placeholder ="Couldn't find account :("
      };
  

    const optionsGet = {
     url:`https://api.faceit.com/users/v1/users?email=${document.getElementById("userEmail").value.toLowerCase()}`,
     type: "GET",
     headers:{
      "Authorization": "Bearer {{setting.token}}",
     },
     contentType: "application/json",
     dataType: "json",
     secure: true,
    };
  
    
    const response = await client.request(optionsGet);

    try {

    const updated = () => {
      document.getElementById("userEmail").value = "";
      document.getElementById("userEmail").placeholder =`${response.payload[0].nickname} has been deactivated :)`};
      client.invoke('resize', { width: '95%', height: '300px' });
      const newDiv = document.createElement("div");
      const newContent = document.createTextNode(`https://backoffice.faceit.com/#/users/${response.payload[0].id}`);
      newDiv.appendChild(newContent);
      const currentDiv = document.getElementById("div1");
      document.body.insertBefore(newDiv, currentDiv);

    
    const id = response.payload[0].id;
    

     const optionsPut = {
       url: `https://api.faceit.com/users/v1/users/${id}`,
       type: "PUT",
       headers:{
         "Accept": "*/*",
         "Accept-Encoding": "gzip, deflate, br",
         "Connection": "keep-alive",
         "accept": "application/json",
         "accept-language": "en-US,en;q=0.9",
         "Authorization": "Bearer {{setting.token}}",
         "authority": "api.faceit.com",
         "content-type": "application/json;charset=UTF-8",
         "faceit-referer": "faceit-backoffice",
         "origin": "https://backoffice.faceit.com",
         "referer": "https://backoffice.faceit.com/",
     
       },
       contentType: "application/json",
       secure: true,
       dataType: "text",
       data: JSON.stringify( { "registration_status": "deactivated" })
              
     };


    const put = await client.request(optionsPut); 
    updated(); 
  
  } catch (err) {
    error()
  }
    } else {
      document.getElementById("userEmail").placeholder = "Field cannot be blank"}
  
  })
  
   